package pages;

import design.ProjectMethods;

public class HomePage extends ProjectMethods{

	public LoginPage clickLogout() {
		driver.findElementByClassName("decorativeSubmit1").click();
		return new LoginPage();
	}






}
